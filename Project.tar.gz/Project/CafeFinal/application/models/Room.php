<?php

class Application_Model_Room extends Zend_Db_Table_Abstract
{
    protected $_name = "room";
    
    function addRoom($data){
        
        return $this->insert($data);
        
    }
     function getRooms($roomno){
        return $this->fetchAll($this->select()->where('roomno=?',$roomno))->toArray();
    }
    
    function listRooms(){
        return $this->fetchAll()->toArray();
    }


}

