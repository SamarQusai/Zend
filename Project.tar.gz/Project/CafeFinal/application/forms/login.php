<?php

class Application_Form_login extends Zend_Form
{

    public function init()
    {
        /* Form Elements & Other Definitions Here ... */
        //$id = new Zend_Form_Element_Hidden("id");
        
        $email = new Zend_Form_Element_Text("email");
        $email->setRequired();
        $email->setAttrib("size", "35");
        $email->setLabel("Email");
        $email->addValidator(new Zend_Validate_EmailAddress());
        $email->getDecorator('label')->setOption('class', 'inline');
        
         $password = new Zend_Form_Element_Password("password");
        $password->setRequired();
        $password->setAttrib("size", "35");
        $password->setLabel("Password");
            $password->getDecorator('Label')->setOption('class', 'inline');

        
       // $password->addValidator(new Zend_Validate_StringLength(array('min'=>5,'max'=>15)));
     
         $submit = new Zend_Form_Element_Submit("Login");

       
        $this->addElements(array( $email , $password,$submit));
        
        
        
    }


}

