<?php

class Application_Model_Order extends Zend_Db_Table_Abstract {

    protected $_name = "orders";
    function selectUsers($start_date , $end_date){
        
        $res = $this->select()->from(array('o' => 'orders'), array('userId',))
              ->join(array('u' => 'user'), 'o.userId = u.id',array('name'))
              ->join(array('od' => 'orderDetails'),'od.orderId = o.orderId ',array('amount'))
              ->join(array('prod' => 'product'),'od.productId = prod.productId ',array('sum1'=> 'SUM(`productPrice`*`amount`)'))
              ->where("orderDate >= ?",  $start_date)
              ->where("orderDate <= ?",  $end_date)
              ->group("name");
        
        $res->setIntegrityCheck(false);
        $row = $this->fetchAll($res)->toArray();
        return $row;
    }
    
    function getOrdersByUserId($id){
       
        $result = $this->select()->from(array('o' => 'orders'), array('userId','orderDate','orderId'))
                ->join(array('u' => 'user'), 'o.userId = u.id',array('name'))
                ->join(array('od' => 'orderDetails'),'od.orderId = o.orderId ',array('amount'))
                ->join(array('prod' => 'product'),'od.productId = prod.productId ',array('sum1'=> 'SUM(`productPrice`*`amount`)'))
                ->where("o.userId= ?",  $id)
                ->group("name");
        $result->setIntegrityCheck(false);
        $row = $this->fetchAll($result)->toArray();
        return $row;
    
                
    }           
            
    function getOrdersForUser($id,$start_date,$end_date){
        $result = $this->select()->from(array('o' => 'orders'),array('orderDate','orderId'))
                ->join(array('od' => 'orderDetails'),'o.orderId = od.orderId' ,'amount')
                ->join(array('p' => 'product'), 'od.productId= p.productId', array('total'=> 'SUM(`productPrice`*`amount`)'))
                ->where("o.userId = ?",$id)
                ->where("orderDate >= ?",  $start_date)
                ->where("orderDate <= ?",  $end_date)
                ->group("orderDate");
                $result->setIntegrityCheck(false);
                $row = $this->fetchAll($result)->toArray();
                return $row;
    }

    function getAllOrders() {
        $select = $this->select()
                ->from(array('o' => 'orders'), array('orderId', 'orderDate', 'roomNo'))
                ->join(array('u' => 'user'), 'o.userId= u.id', array('name'))
                ->join(array('r' => 'room'), 'o.roomno= r.roomno', array('ext'))
                ->where("orderStatus=?","0");

        $select->setIntegrityCheck(false);
        $row = $this->fetchAll($select)->toArray();

        return $row;
    }

    function addOrder($data) {
        if (isset($data['roomNo']) && isset($data['userId'])) {
            $this->insert($data);
            return $this->getAdapter()->lastInsertId();
//             $this->select()->(array(),array());
        }
    }

    function deliver($id) {
   //  return   $this->update(array('orderStatus' => 1), "orderid=" . $id);
     
        
     

        $this->update(array('orderStatus' => 1), "orderid=" . $id);
//        $sql="
//create event resett
//    on schedule every 10 second
//    do
//        begin
//           
//        end ";
        $sql="drop event gold";
        $this->getAdapter()->query($sql);
        $Result = $this->getAdapter()->query("CREATE EVENT gold ON SCHEDULE EVERY 1 MINUTE  DO  update orders set orderstatus=2 where ordserid=".$id." and (orderstatus=1) ;");

   //     $query = $this->getAdapter()->query($sql);
        return true;
     
     
    
    }
    
    
    
    
    function getOrderProducts($id) {

        $select = $this->select()
                ->from(array('o' => 'orders'), array('orderId', 'orderDate', 'roomNo'))
                ->join(array('od' => 'orderDetails'), 'o.orderId= od.orderId', array('productId', 'amount'))
                ->join(array('p' => 'product'), 'od.productid= p.productid', array('productname', 'productprice', 'productpic'))
                ->where("od.orderId=?", $id);

        $select->setIntegrityCheck(false);
        //  echo $select;
        $row = $this->fetchAll($select)->toArray();
        //  var_dump($row);

        return $row;
    }
    function getLastUserOrder($id) {
        $sql = "SELECT max(orderId) FROM  orders WHERE `userId` =". $id;  
        $query = $this->getAdapter()->query($sql);
        $result = $query->fetchAll();
        return $result[0]['max(orderId)'];
        
    }

    function getMyOrders($start,$end,$id){
         $select = $this->select()
             ->from(array('o' => 'orders') ,array('orderId','orderDate', 'orderStatus','userId'))
                     ->join(array('r'=>'orderDetails') ,'o.orderId= r.orderId',array('orderId','amount'))
                   ->join(array('p'=>'product') ,'r.productId= p.productId',array('productName','productPic','productPrice'))
                     ->where('orderDate >= ?',$start)
                       ->where('orderDate <= ?',$end)
                          ->where('userId=?',$id)
                            ->order('orderDate');

         $select->setIntegrityCheck(false);
       
              
        $row = $this->fetchAll($select)->toArray();
        //var_dump($row);
        return $row;
        
    }
    
    function getOrders($id){
        
                   $select = $this->select()
             ->from(array('o' => 'orders'),
                    array('orderId', 'orderDate','orderStatus'))
             
                ->join(array('od' => 'orderDetails'),
                    'o.orderId= od.orderId',
                        
                    array('productId','amount') ) ->where("od.orderid=?",$id)
                   ->join(array('p' => 'product'), 'od.productId= p.productId', array('total'=> 'SUM(`productPrice`*`amount`)'));
         $select->setIntegrityCheck(false);
     
         $row = $this->fetchAll($select)->toArray();
   
        return $row;
    }
    
  function getOrderProduct($id){
        
                   $select = $this->select()

                ->from(array('od' => 'orderDetails'),
                        
                    array('productId','amount','orderId') )
                         
                   ->join(array('p' => 'product'),
                    'od.productId= p.productId',
                    array('productName','productPrice','productPic'))
                   ->where("od.orderId=?",$id);
                                 

           
         $select->setIntegrityCheck(false);
     
         $row = $this->fetchAll($select)->toArray();
  
         
        return $row;
    }
    
    
   function delete_order($id)
   {
      
         $this->delete("orderId=$id");
         return true;
   }
    
 
}